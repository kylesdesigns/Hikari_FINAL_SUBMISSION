const path = require('path');
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = {
    node: {
        __dirname: false
    },
entry: {
    main: './index.js'
},
output: {
    path: path.join(__dirname, 'build'),
    publicPath: "/",
    filename: '[name].js',
    clean: true
},
plugins: [
    new CopyWebpackPlugin({
        patterns: [
            './node_modules/swagger-ui-dist/swagger-ui.css',
            './node_modules/swagger-ui-dist/swagger-ui-bundle.js',
            './node_modules/swagger-ui-dist/swagger-ui-standalone-preset.js',
            './node_modules/swagger-ui-dist/favicon-16x16.png',
            './node_modules/swagger-ui-dist/favicon-32x32.png',
            './node_modules/swagger-ui-dist/index.html'
        ]
    })
],
mode: 'development',
target: 'node',
module: {
    rules: [
        {
            test: /\.js$/,
            exclude: /node_modules/,
            loader: 'babel-loader',
        }
    ]
}
}