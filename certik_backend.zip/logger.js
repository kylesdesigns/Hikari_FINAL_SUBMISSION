const { createLogger, transports, format } = require('winston');

// logging function

const customLogger = createLogger({
  transports: [
    new transports.File({
      filename: 'backend.log',
      level: 'info',
      format: format.combine(format.timestamp(), format.json())
    }),
    new transports.File({
      filename: 'backend-error.log',
      level: 'error',
      format: format.combine(format.timestamp(), format.json())
    })
  ]
});

if (process.env.NODE_ENV !== 'production') {
  customLogger.add(
    new transports.Console({
      format: format.simple()
    })
  );
}

module.exports = { customLogger };
