import toast from 'react-hot-toast';

export const toaster = (type, msg) => {
  switch (type) {
    case 'success':
      toast.success(msg);
      break;
    case 'warning':
      toast.warn(msg);
      break;
    case 'info':
      toast.info(msg);
      break;
    case 'error':
      toast.error(msg);
      break;

    default:
      break;
  }
};
