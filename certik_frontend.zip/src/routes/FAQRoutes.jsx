import FAQLayout from '../layout/FAQLayout';

import FAQ from '../pages/FAQ';

const FAQRoutes = {
  path: '/',
  element: <FAQLayout />,
  children: [
    {
      path: '/faq',
      element: <FAQ />,
    },
  ],
};

export default FAQRoutes;
