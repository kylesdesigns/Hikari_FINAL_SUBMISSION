import { Box, Container, Stack, Typography } from '@mui/material';
import { landingPageBackgroundImage, socials } from '../../utils/content';
import { Socials } from '../../components/Buttons/SocialButton';
import LaunchButton from '../../components/Buttons/LaunchButton';

function Home() {
  return (
    <Container>
      <Box>
        {/* Background */}
        <Box
          sx={{
            position: 'fixed',
            zIndex: -10,
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundImage: `url(${landingPageBackgroundImage})`,
            backgroundRepeat: 'no-repeat',
            height: '100vh',
            width: '100vw',
            backgroundPosition: `right bottom`,
            backgroundSize: `100vw 100vh`,
            objectFit: 'cover',
          }}
        />

        {/* Content */}
        <Container sx={{ height: { xs: '80vh', lg: '80vh' } }}>
          <Stack
            sx={{ height: '100%' }}
            justifyContent={{ xs: 'start', lg: 'center' }}
            mt={{ xs: 15, lg: 0 }}
          >
            <Typography variant='h1' sx={{ letterSpacing: '0.02em', color: '#000' }}>
              HIKARI SWAP
            </Typography>
            <Typography variant='h6' maxWidth='sx' sx={{ letterSpacing: '0.05em' }}>
              Trade with deep liquidity by utilizing our OTC pools and execution algorithms.
            </Typography>
            <Stack sx={{ my: 4 }} direction='row'>
              {socials.map((social) => {
                return (
                  <Socials key={social.linkTo} href={social.linkTo} target={'_blank'}>
                    {social.icon}
                  </Socials>
                );
              })}
            </Stack>
            <Box>
              <LaunchButton
                sx={{
                  height: 58,
                  width: 170,
                  color: 'text.primary',
                  borderColor: 'text.primary',
                  px: 2,
                }}
                onClick={() => window.open('/trade', '_self')}
              />
            </Box>
          </Stack>
        </Container>
      </Box>
    </Container>
  );
}
export default Home;
