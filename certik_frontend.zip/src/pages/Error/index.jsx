import { Box } from '@mui/material';

const Error = () => {
  return <Box>Error Page</Box>;
};

export default Error;
