import {
  Box,
  Button,
  Container,
  FormControl,
  IconButton,
  Stack,
  TextField,
  Typography,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import SwapVertIcon from '@mui/icons-material/SwapVert';
import { useEffect, useState } from 'react';
import { useAccount, useBalance } from 'wagmi';

const PayAndReceiveInput = ({
  invert,
  onChangedInvert,
  account,
  sourceToken,
  sellAmount,
  buyAmount,
  onChangedSellAmount,
  onChangedBuyAmount,
}) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const [showBalance, setShowBalance] = useState(false);

  const { isConnected } = useAccount();

  const { address } = useAccount();

  const balanceEth = useBalance({
    address: account,
    watch: true,
    chainId: 1,
    // onSettled(data, error) {
    //   console.log('Settled', { data, error });
    // },
  });

  const balanceHikari = useBalance({
    address: account,
    token: '0xd4126f195a8de772eeffa61a4ab6dd43462f4e39',
    watch: true,
    chainId: 1,
    // onSettled(data, error) {
    //   console.log(address);
    //   console.log('Settled 2', { data, error });
    // },
  });

  useEffect(() => {
    if (account) {
      setShowBalance(true);
    } else {
      setShowBalance(false);
    }
  }, [account]);

  return (
    <Container
      sx={{
        display: { xs: 'block', md: 'flex' },
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 3,
        px: 1,
        py: 1,
      }}
    >
      {/* pay and receive */}
      {/* You pay */}
      <Box
        sx={{
          mx: 0,
          py: 1,
          px: 2,
          //   border: '1px solid #20242A',
          borderRadius: 3,
          background: '#f8eecd',
        }}
      >
        <Stack>
          {/* header */}
          <Stack direction='row' display='flex' justifyContent='space-between'>
            <Typography sx={{ fontSize: 12, color: 'gray' }}>You pay</Typography>

            {showBalance && (
              <Typography sx={{ fontSize: 12, color: 'gray' }}>
                Balance:{' '}
                {invert
                  ? Number(balanceHikari.data?.formatted).toFixed(6)
                  : Number(balanceEth.data?.formatted).toFixed(6)}
              </Typography>
            )}
          </Stack>
          {/* input and currency */}
          <Stack direction='row' display='flex' justifyContent='space-between'>
            <FormControl variant='standard'>
              <TextField
                inputProps={{
                  inputMode: 'numeric',
                  pattern: '^[0-9]*[.,]?[0-9]*$',
                  placeholder: '0.0',
                }}
                sx={{
                  // width: { xs: '70vw', md: '12em' },
                  fontSize: 20,
                  '& fieldset': { border: 'none' },
                }}
                value={sellAmount}
                onChange={onChangedSellAmount}
                fullWidth
              />
            </FormControl>

            <Box justifyContent='center' alignItems='center' display='flex'>
              <Button
                variant='contained'
                sx={{ background: '#2D2F36', borderRadius: 3 }}
                onClick={onChangedInvert}
              >
                {invert ? (
                  <Stack direction='row'>
                    <img
                      src='https://assets.coingecko.com/coins/images/28953/standard/HIKARI.png?1696527926'
                      width='20px'
                      height='20px'
                    />
                    <Typography sx={{ color: '#ffffff', ml: 1 }}>Hikari</Typography>
                  </Stack>
                ) : (
                  <Stack direction='row'>
                    <img
                      src='https://assets.coingecko.com/coins/images/279/standard/ethereum.png?1696501628'
                      width='20px'
                      height='20px'
                    />
                    <Typography sx={{ color: '#ffffff', ml: 1 }}>ETH</Typography>
                  </Stack>
                )}
              </Button>
            </Box>
          </Stack>
          {/* buy amount quick select */}
        </Stack>
      </Box>
      {/* swap horiz */}
      <Box display='flex' justifyContent='center' sx={{ width: { xs: '100%', md: '20px' } }}>
        <IconButton
          sx={{
            background: '#2D2F36',
            color: '#ffffff',
            p: 1,
            borderRadius: 1000,
            ml: { xs: 0, md: -1 },
            my: { xs: -1, md: 0 },
          }}
        >
          {isMobile ? (
            <SwapVertIcon sx={{ fontSize: 12 }} />
          ) : (
            <SwapHorizIcon sx={{ fontSize: 12 }} />
          )}
        </IconButton>
      </Box>
      {/* You receive */}
      <Box
        sx={{
          mx: 0,
          ml: { xs: 0, md: -1 },
          py: 1,
          px: 2,
          //   border: '1px solid #20242A',
          borderRadius: 3,
          background: '#f8eecd',
        }}
      >
        <Stack>
          {/* header */}
          <Stack direction='row' display='flex' justifyContent='space-between'>
            <Typography sx={{ fontSize: 12, color: 'gray' }}>You receive</Typography>
            {showBalance && (
              <Typography sx={{ fontSize: 12, color: 'gray' }}>
                Balance:{' '}
                {invert
                  ? Number(balanceEth.data?.formatted).toFixed(6)
                  : Number(balanceHikari.data?.formatted).toFixed(6)}
              </Typography>
            )}
          </Stack>
          {/* input and currency */}
          <Stack direction='row' display='flex' justifyContent='space-between'>
            <FormControl variant='standard'>
              <TextField
                inputProps={{
                  inputMode: 'numeric',
                  pattern: '^[0-9]*[.,]?[0-9]*$',
                  placeholder: '0.0',
                }}
                sx={{
                  // width: { xs: '70vw', md: '12em' },
                  fontSize: 20,
                  '& fieldset': { border: 'none' },
                }}
                fullWidth
                value={buyAmount}
                onChange={onChangedBuyAmount}
              />
            </FormControl>

            <Box justifyContent='center' alignItems='center' display='flex'>
              <Button
                variant='contained'
                sx={{ background: '#2D2F36', borderRadius: 3 }}
                onClick={onChangedInvert}
              >
                {invert ? (
                  <Stack direction='row'>
                    <img
                      src='https://assets.coingecko.com/coins/images/279/standard/ethereum.png?1696501628'
                      width='20px'
                      height='20px'
                    />
                    <Typography sx={{ color: '#ffffff', ml: 1 }}>ETH</Typography>
                  </Stack>
                ) : (
                  <Stack direction='row'>
                    <img
                      src='https://assets.coingecko.com/coins/images/28953/standard/HIKARI.png?1696527926'
                      width='20px'
                      height='20px'
                    />
                    <Typography sx={{ color: '#ffffff', ml: 1 }}>Hikari</Typography>
                  </Stack>
                )}
              </Button>
            </Box>
          </Stack>
          {/* buy amount quick select */}
        </Stack>
      </Box>
    </Container>
  );
};

export default PayAndReceiveInput;
