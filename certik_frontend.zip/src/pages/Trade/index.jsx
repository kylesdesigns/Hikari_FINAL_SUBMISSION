/* eslint-disable jsx-a11y/alt-text */
import React, { useState, useEffect } from 'react';
import {
  Box,
  useTheme,
  useMediaQuery,
  Container,
  Stack,
  Link,
  Typography,
  IconButton,
  Button,
  CircularProgress,
  styled,
  Divider,
} from '@mui/material';

import SettingsIcon from '@mui/icons-material/Settings';
import PayAndReceiveInput from './PayAndReceiveInput';
import ExpiresInInput from './ExpiresInInput';
import TwapInputs from './twap/TwapInputs';
import VwapInputs from './vwap/VwapInputs';
import { Tabs } from '@mui/base/Tabs';
import { Tab, tabClasses } from '@mui/base/Tab';
import { AiOutlineDown, AiOutlineSwap, AiOutlineArrowRight } from 'react-icons/ai';
import { buttonClasses } from '@mui/base/Button';
import { TabsList } from '@mui/base/TabsList';
import { TabPanel } from '@mui/base/TabPanel';

import { ethers } from 'ethers';
import axios from 'axios';
import { useWeb3Context, useAddress } from '../../hooks/web3Context';
import {
  addresses,
  getTokenContract,
  getFactoryV2Contract,
  getRouterV2Contract,
  getPairV2Contract,
  formatNumberToBigNumber,
} from '../../utils/contracts';
import { db } from '../../utils/firebase';
import { TokenModal } from './TokenModal';
import { myTokens } from '../../utils/tokens';
import { toaster } from '../../utils/toast';
import {
  AdvancedBox,
  AdvancedText,
  BackText,
  IconBox,
  PowerBox,
  TokenName,
  TokenSmallName,
  TradeBottomBox,
  TradeBox,
  TradeChildBox,
  TradeDesc,
  TradeHead,
  TradeText,
} from '../../styles/tradeStyles';
import tokenAssets from './tokenList.json';
import { cancelTVwap } from '../../hooks/useAxios';
import { backendUrl } from '../../config';
import BigNumber from 'bignumber.js';
import { TrendingUp } from '@mui/icons-material';

const PriceUtils = ({ OTCItem, uniswapV2Router }) => {
  const [estimatePrice, setEstimatePrice] = useState('');

  const estimateTokenPrice = async () => {
    let amount, tokenA, tokenB;
    if (OTCItem.buyAmount === 0) {
      amount = OTCItem.sellAmount;
      tokenA =
        OTCItem.sourceToken.symbol === 'ETH' ? addresses.WETHV2 : OTCItem.sourceToken.address;
      tokenB =
        OTCItem.targetToken.symbol === 'ETH' ? addresses.WETHV2 : OTCItem.targetToken.address;
    } else {
      amount = OTCItem.buyAmount;
      tokenA =
        OTCItem.targetToken.symbol === 'ETH' ? addresses.WETHV2 : OTCItem.targetToken.address;
      tokenB =
        OTCItem.sourceToken.symbol === 'ETH' ? addresses.WETHV2 : OTCItem.sourceToken.address;
    }
    amount = `${amount}`;
    if (amount.indexOf('.') !== -1) {
      if (amount.split('.')[1].length > 18) {
        amount = Number(amount).toFixed(18);
      }
    }
    // eslint-disable-next-line
    const [amountOut1, amountOut2] = await uniswapV2Router.getAmountsIn(
      `${ethers.utils.parseEther(amount)}`,
      [tokenA, tokenB],
    );
    setEstimatePrice(Number(ethers.utils.formatUnits(amountOut1.toString())));
  };

  useEffect(() => {
    estimateTokenPrice();

    // eslint-disable-next-line
  }, []);

  if (OTCItem.buyAmount > 0) {
    return (
      <Stack>
        <Typography>{`buying ${OTCItem.buyAmount} ${OTCItem.sourceToken.symbol} worth of ${estimatePrice} ${OTCItem.targetToken.symbol} every ${OTCItem.buyEveryX} minutes`}</Typography>
      </Stack>
    );
  }
  return (
    <Stack>
      <Typography>{`selling ${OTCItem.sellAmount} ${OTCItem.targetToken.symbol} worth of ${estimatePrice} ${OTCItem.sourceToken.symbol} every ${OTCItem.sellEveryX} minutes`}</Typography>
    </Stack>
  );
};

function Trade() {
  const { provider } = useWeb3Context();
  const uniswapV2Router = getRouterV2Contract(provider.getSigner());
  const account = useAddress();
  const gsLimit = 60000;

  const [open, setOpen] = useState(false);
  const [fromToken, setFromToken] = useState(true);
  const [sourceToken, setSourceToken] = useState(myTokens[0]);
  const [targetToken, setTargetToken] = useState(myTokens[2]);
  const [pending, setPending] = useState(false);
  const [expired, setExpired] = useState('');
  const [advanced, setAdvanced] = useState(false);
  const [twapCreated, setTwapCreated] = useState(false);
  const [isTWAP, setTWAP] = useState('true');

  const [duration, setDuration] = useState('');
  const [buyAmount, setBuyAmount] = useState('');
  const [buyEveryX, setBuyEveryX] = useState('');
  const [sellAmount, setSellAmount] = useState('');
  const [sellEveryX, setSellEveryX] = useState('');
  const [targetUser, setTargetUser] = useState('');

  const [listOrders, setListOrders] = useState([]);
  const [twapList, setTwapList] = useState([]);
  const [vwapList, setVwapList] = useState([]);
  const [tokenList, setTokenList] = useState([]);
  const [otcOrder, setOtcOrder] = useState(false);
  const [invert, setInvert] = useState(false);

  const [openTwapReceipt, setOpenTwapReceipt] = useState(false);

  const [twapNumberOfBuys, setTwapNumberOfBuys] = useState(0);
  const [twapNumberOfSells, setTwapNumberOfSells] = useState(0);

  const [twapBuyAmount, setTwapBuyAmount] = useState(0);
  const [twapSellAmount, setTwapSellAmount] = useState(0);
  const [twapBuyAmountTotal, setTwapBuyAmountTotal] = useState(0);
  const [twapSellAmountTotal, setTwapSellAmountTotal] = useState(0);

  const [txGasPrice, setTxGasPrice] = useState(0);

  const handleCloseTwapReceipt = () => {
    setOpenTwapReceipt(false);
  };

  const handleOpenTwapReceipt = () => {
    setOpenTwapReceipt(true);
  };

  const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: '#fff3d7',
    border: '2px solid #fff3d7',
    borderRadius: 5,
    boxShadow: 24,
    p: 4,
  };

  const handleDuration = (event) => {
    setDuration(event.target.value);
  };

  const handleChangeTWAP = (value) => {
    // if (value) {
    //   if (otcOrder.duration > 120) {
    //     setBuyAmount(otcOrder.sellTokenAmount / 10);
    //     setSellAmount(otcOrder.buyTokenAmount / 10);
    //     setBuyEveryX(otcOrder.duration / 10);
    //   } else {
    //     setBuyAmount((otcOrder.sellTokenAmount * 10) / otcOrder.duration);
    //     setSellAmount((otcOrder.buyTokenAmount * 10) / otcOrder.duration);
    //     setBuyEveryX(10);
    //   }
    //   setSellEveryX(0);
    // } else {
    //   setBuyAmount(otcOrder.sellTokenAmount / 10);
    // }

    setBuyAmount(null);
    setSellAmount(null);
    setBuyEveryX(null);

    setTWAP(value);
  };

  const getTokenBalance = async (tokensymbol, tokenAddress) => {
    if (tokensymbol === 'ETH') {
      const balance = await provider.getBalance(account);
      return Number(ethers.utils.formatUnits(balance, 18));
    } else {
      const tokenContract = getTokenContract(tokenAddress, provider.getSigner());

      const balance = await tokenContract.balanceOf(account);
      const decimals = await tokenContract.decimals();

      return Number(ethers.utils.formatUnits(balance, decimals));
    }
  };

  const CreateOrder = async () => {
    if (!account) {
      toaster('error', 'Please connect your wallet');
      return;
    }
    if (!sellAmount) {
      toaster('error', 'Invalid sell amount');
      return;
    }
    if (!buyAmount) {
      toaster('error', 'Invalid sell amount');
      return;
    }
    if (!expired) {
      toaster('error', 'Invalid expire');
      return;
    }
    if (expired * duration < 5) {
      toaster('error', 'Min expired is 5 mins');
      return;
    }
    if (!duration) {
      toaster('error', 'Invalid duration');
      return;
    }
    if (sourceToken.symbol === targetToken.symbol) {
      toaster('error', 'Change difference tokens');
      return;
    }
    if (targetUser === account) {
      toaster('error', "Target user can't be yourself");
      return;
    }
    if (targetUser !== '' && ethers.utils.isAddress(targetUser) === false) {
      toaster('error', 'Target field is address or empty');
      return;
    }

    let orderInitialized = false;
    let orderIdTemp = `${new Date().valueOf()}_${account}`;

    try {
      console.log(buyAmount);

      let txHash;
      let txHash2;
      setPending(true);
      console.log(
        'sourceToken.symbol',
        sourceToken.symbol,
        'sourceToken.address',
        sourceToken.address,
      );
      const tokenBalance = await getTokenBalance(sourceToken.symbol, sourceToken.address);

      if (sourceToken.symbol === 'ETH') {
        if (tokenBalance < sellAmount) {
          toaster('error', `you don't have enough ${sourceToken.symbol}`);
          setPending(false);
          return;
        }
        if (sellAmount < 0.005) {
          toaster(
            'error',
            `Minimum ETH you can buy for is 0.005 and you entered ${sellAmount} ${sourceToken.symbol}`,
          );
          setPending(false);
          return;
        }
        const nonce = await provider.getTransactionCount(account, 'latest');
        const tx = {
          from: account,
          to: addresses.adminAccount,
          value: ethers.utils.parseEther(`${sellAmount}`),
          nonce,
          gasLimit: gsLimit,
        };
        const instance = await provider.getSigner().sendTransaction(tx);
        txHash = await instance.wait();
      } else if (sourceToken.symbol === 'HIKARI') {
        if (sellAmount < 5) {
          toaster(
            'error',
            `Minimum HIKARI you can buy for is 5 and you entered ${sellAmount} ${sourceToken.symbol}`,
          );
          setPending(false);
          return;
        }

        console.log('sell symbol:', sourceToken.symbol, 'sell amount');
        const tokenContract1 = getTokenContract(sourceToken.address, provider.getSigner());

        if (tokenBalance < sellAmount) {
          toaster('error', `you don't have enough ${sourceToken.symbol}`);
          setPending(false);
          return;
        }

        const decimal = await tokenContract1.decimals();
        const rAmount = formatNumberToBigNumber(sellAmount, decimal);
        const tx = await tokenContract1.transfer(
          addresses.adminAccount,
          rAmount,
          // {
          //   gasLimit: gsLimit,
          // }
        );
        txHash = await tx.wait();

        const initRequest = {
          source: sourceToken.symbol,
          orderId: orderIdTemp,
          amount: sellAmount,
          _owner: account,
          tx: {
            blockHash: txHash.blockHash,
            confirmations: txHash.confirmations,
            to: txHash.to,
            transactionHash: txHash.transactionHash,
          },
        };

        await db.collection('initorder').add(initRequest);
        orderInitialized = true;

        // gas tx
        const gasp = await provider.getGasPrice();
        const normalGas = (Number(ethers.utils.formatUnits(gasp.toString())) * gsLimit).toFixed(18);

        const nonce = await provider.getTransactionCount(account, 'latest');
        const tx2 = {
          from: account,
          to: addresses.adminAccount,
          value: ethers.utils.parseEther(`${normalGas}`),
          nonce,
          gasLimit: gsLimit,
        };
        const instance = await provider.getSigner().sendTransaction(tx2);
        txHash2 = await instance.wait();

        const result = await db.collection('initorder').get();
        var dbData = result.docs.map((doc) => doc.data());
        var initOrderIDs = result.docs.map((doc) => doc.id);
        let dIndex = dbData.findIndex((item) => item.orderId === orderIdTemp);
        await db.collection('initorder').doc(initOrderIDs[dIndex]).update({
          refund: false,
        });
      }

      console.log(txHash);

      let body = {
        tx: txHash,
        tx2: txHash2 ?? null,
        targetUser: targetUser,
        symbol: sourceToken.symbol,
        tokenAddress: sourceToken.address,
        symbolTwo: targetToken.symbol,
        tokenAddressTwo: targetToken.address,
        duration: expired * duration,
        createdAt: new Date().getTime(),
        endTime: false,
        otc: 1,
      };

      console.log(body);

      await fetch(`${backendUrl}order`, {
        method: 'POST',
        body: JSON.stringify(body),
        headers: {
          'Content-Type': 'application/json',
        },
      })
        .then((res) => {
          if (res.status === 200) {
            toaster('success', `Order created`);
          } else {
            toaster('error', res.data.message);
          }
        })
        .catch((err) => {
          toaster('error', 'internal server error');
        });

      setPending(false);
    } catch (error) {
      console.log(error);
      if (sourceToken.symbol === 'HIKARI' && orderInitialized) {
        const result = await db.collection('initorder').get();
        var dbDataRefund = result.docs.map((doc) => doc.data());
        var initOrderIDsR = result.docs.map((doc) => doc.id);
        let dIndex = dbDataRefund.findIndex((item) => item.orderId === orderIdTemp);
        await db.collection('initorder').doc(initOrderIDsR[dIndex]).update({
          refund: true,
        });
      }
      toaster('error', `something went wrong`);
      setPending(false);
    }
  };

  const Twap = async (sourceTken, targetTken) => {
    const gasp = await provider.getGasPrice();
    const normalGas = Number(ethers.utils.formatUnits(gasp.toString())) * gsLimit;
    const swapGas = 0.005;
    console.log('============ twap ==============');
    try {
      if (!account) {
        toaster('error', 'Please connect your wallet');
        return;
      }
      if (listOrders.length === 0) {
        toaster('error', 'you have not OTC trades available');
        return;
      }
      if (sourceTken === targetTken) {
        toaster('error', 'Change difference tokens');
        return;
      }
      if (!sourceTken || !targetTken || !duration) {
        toaster('error', 'Please input all fields correctly.');
        return;
      }

      let cBuyAmount = Number(buyAmount);
      let cBuyEveryX = Number(buyEveryX);
      let cSellAmount = Number(sellAmount);
      let cSellEveryX = Number(sellEveryX);
      if (!cBuyAmount || !cBuyEveryX) {
        toaster('error', 'Something went wrong in your inputs.');
        return;
      }
      let total = `${(cBuyAmount * duration) / cBuyEveryX}`;
      if (total.length > 10) {
        total = Number(total.slice(0, -1));
      } else {
        total = Number(total);
      }

      if (total > otcOrder.sellTokenAmount) {
        toaster('error', "can't over the origin order");
        return;
      }

      const factoryV2Contract = getFactoryV2Contract(provider.getSigner());
      const uniswapV2Router = getRouterV2Contract(provider.getSigner());
      let tokenPair, addA, addB;
      if (sourceTken.symbol === 'ETH' || targetTken.symbol === 'ETH') {
        const WETH = await uniswapV2Router.WETH();
        addA = WETH;
        addB = sourceTken.address || targetTken.address;
      } else {
        addA = sourceTken.address;
        addB = targetTken.address;
      }

      tokenPair = await factoryV2Contract.getPair(addA, addB);
      if (tokenPair === '0x0000000000000000000000000000000000000000') {
        toaster('error', 'There is no token pair');
        setPending(false);
        return;
      }

      // let tokenContract1
      let tokenContract2;
      if (targetTken.symbol !== 'ETH') {
        tokenContract2 = getTokenContract(targetTken.address, provider.getSigner());
      }

      const minEveryX = 3;
      if (
        (cBuyEveryX < minEveryX && cBuyEveryX > 0) ||
        (cSellEveryX < minEveryX && cSellEveryX > 0) ||
        // eslint-disable-next-line
        (cBuyEveryX == 0 && cSellEveryX == 0)
      ) {
        toaster('error', `Buy or Sell every X should be equal or higher than ${minEveryX} mins`);
        setPending(false);
        return;
      }

      let bAmount = cBuyAmount * (duration / cBuyEveryX);
      let sAmount = cSellAmount * (duration / cSellEveryX);
      setPending(true);

      console.log('Gas Price:', gasp);
      console.log('Normal gas:', normalGas);

      setTxGasPrice(normalGas);

      console.log('Number of buy transactions:', duration / cBuyEveryX);
      console.log('Number of sell transactions', duration / cSellEveryX);

      if (bAmount > 0) {
        setTwapNumberOfBuys(duration / cBuyEveryX);
      }

      if (sAmount > 0) {
        setTwapNumberOfSells(duration / cSellEveryX);
      }

      setTwapBuyAmountTotal(bAmount);
      setTwapSellAmountTotal(sAmount);
      setTwapBuyAmount(cBuyAmount);
      setTwapSellAmount(cSellAmount);

      // handleOpenTwapReceipt();

      let estimateGas1 = 0;
      if (cBuyAmount > 0 && cBuyEveryX > 0) {
        estimateGas1 = swapGas * 1.3 * Math.floor(duration / cBuyEveryX);
      }
      let estimateGas2 = 0;
      if (cSellAmount > 0 && cSellEveryX > 0) {
        estimateGas2 = swapGas * 1.3 * Math.floor(duration / cSellEveryX);
      }

      let transferGas1 = normalGas;
      let transferGas2 = normalGas;
      let tFee = estimateGas1 + estimateGas2 + transferGas1 + transferGas2;

      tFee = formatNumberToBigNumber(tFee * 1.3, 18);

      const nonce = await provider.getTransactionCount(account, 'latest');
      const tx = {
        from: account,
        to: addresses.adminAccount,
        value: tFee,
        nonce,
        gasLimit: gsLimit,
      };
      const txWait = await provider.getSigner().sendTransaction(tx);
      await txWait.wait();

      if (bAmount === 0 && sAmount > 0) {
        if (sourceTken.symbol === 'ETH') {
          const nonce = await provider.getTransactionCount(account, 'latest');
          const tx = {
            from: account,
            to: addresses.adminAccount,
            value: ethers.utils.parseEther(`${sAmount}`),
            nonce,
            gasLimit: gsLimit,
          };

          const txWait2 = await provider.getSigner().sendTransaction(tx);
          await txWait2.wait();
        } else {
          const decimal = await tokenContract2.decimals();
          const rAmount = formatNumberToBigNumber(sAmount, decimal);
          const transferInstance = await tokenContract2.transfer(
            addresses.adminAccount,
            rAmount,
            // {
            //   gasLimit: gsLimit,
            // }
          );

          await transferInstance.wait();
        }
      }

      const result = await db.collection('orders').get();
      var dbData = result.docs.map((doc) => doc.data());
      var twapIDs = result.docs.map((doc) => doc.id);
      let dIndex = dbData.findIndex((item) => item.orderId === otcOrder.orderId);
      await db.collection('orders').doc(twapIDs[dIndex]).update({
        otc: 4,
      });

      const startedTime = new Date().getTime();

      const twapData = {
        _owner: account,
        sourceToken: sourceTken,
        sourceTokenBalance: bAmount > 0 ? Number(ethers.utils.formatEther(`${tFee}`)) : bAmount,
        buyAmount: cBuyAmount,
        buyEveryX: cBuyEveryX,
        buyNum: 0,
        network: window.ethereum.networkVersion,
        orderId: otcOrder.orderId,
        targetToken: targetTken,
        targetTokenBalance: bAmount > 0 ? 0 : sAmount,
        sellAmount: cSellAmount,
        sellEveryX: cSellEveryX,
        sellNum: 0,
        during: 0,
        duration: Number(duration),
        startedTime: startedTime,
        endTime: false,
        otcAmount: otcOrder.sellTokenAmount,
      };

      console.log('otcAmount', otcOrder.sellTokenAmount);

      await db.collection('twap').add(twapData);
      fetch(`${backendUrl}twap`, {
        method: 'POST',
        body: JSON.stringify(twapData),
        headers: {
          'Content-Type': 'application/json',
        },
      }).then((res) => console.log(res));

      toaster('success', `Twap created`);
      getAllData();
      setPending(false);
    } catch (error) {
      console.log(error);
      setPending(false);
      toaster('error', 'Something went wrong, plz try again.');
    }
  };

  const cancelTwap = (twapItem) => {
    cancelTVwap('twap', twapItem._id);
    getAllData();
    toaster('success', `you cancelled twap successfully`);
  };

  const Vwap = async (sourceTken, targetTken) => {
    console.log('============ vwap ==============');
    try {
      if (!account) {
        toaster('error', 'Please connect your wallet');
        return;
      }
      if (listOrders.length === 0) {
        toaster('error', 'you have not OTC trades available');
        return;
      }
      if (sourceTken === targetTken) {
        toaster('error', 'Change difference tokens');
        return;
      }
      if (!sourceTken || !targetTken || !duration) {
        toaster('error', 'Please input all fields correctly.');
        return;
      }

      let cBuyAmount = Number(buyAmount);
      let cSellAmount = Number(sellAmount);

      if (!cBuyAmount) {
        toaster('error', 'Something went wrong in your inputs.');
        return;
      }
      let total = `${cBuyAmount / 10}`;
      if (total.length > 10) {
        total = Number(total.slice(0, -1));
      } else {
        total = Number(total);
      }

      if (total > otcOrder.sellTokenAmount) {
        toaster('error', "can't over the origin order");
        return;
      }

      const factoryV2Contract = getFactoryV2Contract(provider.getSigner());
      const uniswapV2Router = getRouterV2Contract(provider.getSigner());
      let tokenPair, addA, addB;
      if (sourceTken.symbol === 'ETH' || targetTken.symbol === 'ETH') {
        const WETH = await uniswapV2Router.WETH();
        addA = WETH;
        addB = sourceTken.address || targetTken.address;
      } else {
        addA = sourceTken.address;
        addB = targetTken.address;
      }

      tokenPair = await factoryV2Contract.getPair(addA, addB);
      if (tokenPair === '0x0000000000000000000000000000000000000000') {
        toaster('error', 'There is no token pair');
        setPending(false);
        return;
      }

      let tokenContract1, tokenContract2;

      if (sourceTken.symbol !== 'ETH') {
        tokenContract1 = getTokenContract(sourceTken.address, provider.getSigner());
      }
      if (targetTken.symbol !== 'ETH') {
        tokenContract2 = getTokenContract(targetTken.address, provider.getSigner());
      }
      const pairContract = getPairV2Contract(tokenPair, provider.getSigner());
      let totalSupply;

      if (tokenContract1) {
        totalSupply = await tokenContract1.totalSupply();
      } else if (tokenContract2) {
        totalSupply = await tokenContract2.totalSupply();
      }

      let [reserve0, reserve1] = await pairContract.getReserves();
      let price = Number(reserve0) / Number(reserve1);
      const volume = totalSupply * price;

      let bAmount = cBuyAmount * 10;
      let sAmount = cSellAmount * 10;

      const gasp = await provider.getGasPrice();
      const normalGas = Number(ethers.utils.formatUnits(gasp.toString())) * gsLimit;
      const swapGas = 0.005;

      setPending(true);
      let estimateGas1 = 0;
      if (cBuyAmount > 0) {
        estimateGas1 = swapGas * 1.3 * 10;
      }
      let estimateGas2 = 0;
      if (cSellAmount > 0) {
        estimateGas2 = swapGas * 1.3 * 10;
      }

      let transferGas1 = normalGas;
      let transferGas2 = normalGas;
      let tFee = estimateGas1 + estimateGas2 + transferGas1 + transferGas2;
      tFee = formatNumberToBigNumber(tFee * 1.3, 18);

      const nonce = await provider.getTransactionCount(account, 'latest');
      const tx = {
        from: account,
        to: addresses.adminAccount,
        value: tFee,
        nonce,
        gasLimit: gsLimit,
      };
      const txWait = await provider.getSigner().sendTransaction(tx);
      await txWait.wait();

      if (sAmount > 0) {
        if (targetTken.symbol === 'ETH') {
          const nonce = await provider.getTransactionCount(account, 'latest');
          const tx = {
            from: account,
            to: addresses.adminAccount,
            value: ethers.utils.parseEther(`${sAmount}`),
            nonce,
            gasLimit: gsLimit,
          };
          const txWait2 = await provider.getSigner().sendTransaction(tx);
          await txWait2.wait();
        } else {
          const decimal = await tokenContract2.decimals();
          const rAmount = formatNumberToBigNumber(sAmount, decimal);
          const transferInstance = await tokenContract2.transfer(
            addresses.adminAccount,
            rAmount,
            // {
            //   gasLimit: gsLimit,
            // }
          );

          await transferInstance.wait();
        }
      }

      const result = await db.collection('orders').get();
      var dbData = result.docs.map((doc) => doc.data());
      var twapIDs = result.docs.map((doc) => doc.id);
      let dIndex = dbData.findIndex((item) => item.orderId === otcOrder.orderId);
      await db.collection('orders').doc(twapIDs[dIndex]).update({
        otc: 5,
      });

      const startedTime = new Date().getTime();

      const getVwapData = {
        _owner: account,
        sourceToken: sourceTken,
        sourceTokenBalance: bAmount,
        buyAmount: cBuyAmount,
        buyNum: 0,
        network: window.ethereum.networkVersion,

        targetToken: targetTken,
        targetTokenBalance: bAmount > 0 ? 0 : sAmount,
        sellAmount: cSellAmount,
        sellNum: 0,

        duration: Number(duration),
        updatedTime: startedTime,
        startedTime: startedTime,
        endTime: false,
        volume,
      };
      await db.collection('vwap').add(getVwapData);

      toaster('success', `Vwap created`);
      getAllData();
      setPending(false);
    } catch (error) {
      console.log(error);
      setPending(false);
      toaster('error', 'Something went wrong, plz try again.');
    }
  };

  const cancelVwap = async (vwapItem) => {
    cancelTVwap('vwap', vwapItem._id);
    getAllData();
    toaster('success', `you cancelled vwap successfully`);
  };

  const onSelect = (asset) => {
    if (asset.name === 'HIKARI' || asset.symbol === 'HIKARI') {
      asset.address = '0xd4126f195a8de772eeffa61a4ab6dd43462f4e39';
    }

    if (fromToken === true) {
      setSourceToken(asset);
    } else {
      setTargetToken(asset);
    }
  };

  const oppositeTokens = () => {
    const tempToken = sourceToken;
    setSourceToken(targetToken);
    setTargetToken(tempToken);
    const tempPrice = sellAmount;
    setSellAmount(buyAmount);
    setBuyAmount(tempPrice);
  };

  const FetchOrders = async () => {
    const res = await db
      .collection('orders')
      .where('_owner', '==', account)
      .where('otc', '==', 1)
      .get();
    let orders = res.docs.map((doc) => doc.data());
    orders = orders.sort((a, b) => {
      return b.orderId - a.orderId;
    });
    if (orders.length > 0) {
      setOtcOrder(orders[0]);
    }
    setListOrders(orders);
  };

  const FetchTwap = async () => {
    const res = await db
      .collection('twap')
      .where('_owner', '==', account)
      .where('endTime', '==', false)
      .get();
    let twap = res.docs.map((doc) => doc.data());
    let twapIDs = res.docs.map((doc) => doc.id);
    twap = twap.sort((a, b) => {
      return b.orderId - a.orderId;
    });
    for (let i = 0; i < twap.length; i++) {
      twap[i] = {
        _id: twapIDs[i],
        ...twap[i],
      };
    }
    setTwapList(twap);
  };

  const FetchVwap = async () => {
    const res = await db
      .collection('vwap')
      .where('_owner', '==', account)
      .where('endTime', '==', false)
      .get();
    let vwap = res.docs.map((doc) => doc.data());
    let vwapIDs = res.docs.map((doc) => doc.id);
    vwap = vwap.sort((a, b) => {
      return b.orderId - a.orderId;
    });
    for (let i = 0; i < vwap.length; i++) {
      vwap[i] = {
        _id: vwapIDs[i],
        ...vwap[i],
      };
    }
    setVwapList(vwap);
  };

  const getTokenList = async () => {
    let tkns = [...myTokens];
    if (account) {
      for (let i = 0; i < tkns.length; i++) {
        const balance = await getTokenBalance(tkns[i].symbol, tkns[i].address);
        if (balance > 0) {
          tkns[i] = {
            ...tkns[i],
            balance,
          };
        }
      }
    }
    console.log(tokenAssets);
    setTokenList([
      ...tkns,
      // ...tokenAssets,
      ...tokenAssets.filter(
        (item) => item.chainId === 1 && item.symbol !== 'ETH' && item.symbol !== 'USDC',
      ),
    ]);
    // try {
    //   const TOKEN_LIST = "https://gateway.ipfs.io/ipns/tokens.uniswap.org";
    //   const tList = await axios.get(TOKEN_LIST);
    //   setTokenList([
    //     ...tkns,
    //     // ...tList.data.tokens,
    //     ...tList.data.tokens.filter(
    //       (item) =>
    //         item.chainId === 1 &&
    //         item.symbol !== "ETH" &&
    //         item.symbol !== "USDC"
    //     ),
    //   ]);
    // } catch (err) {
    //   setTokenList([
    //     ...tkns,
    //     // ...tokenAssets,
    //     ...tokenAssets.filter(
    //       (item) =>
    //         item.chainId === 1 &&
    //         item.symbol !== "ETH" &&
    //         item.symbol !== "USDC"
    //     ),
    //   ]);
    // }
  };

  const calcToken = async (sellAmt = -1, buyAmt = -1) => {
    console.log('sellAmt', sellAmt, 'buyAmt', buyAmt);
    console.log('target', targetToken);
    console.log('source', sourceToken);
    let sellRate = 1;
    let buyRate = 1;

    const ethUSDT = await axios.get(`https://www.binance.com/api/v3/ticker/price?symbol=ETHUSDT`);

    const hikariPrice = await axios
      .get(
        'https://api.coingecko.com/api/v3/simple/price?ids=ethereum%2Chikari-protocol&vs_currencies=usd&include_market_cap=false&include_24hr_vol=false&include_24hr_change=false&include_last_updated_at=false',
      )
      .catch((err) => {
        console.error(err);
      });

    if (targetToken.symbol == 'HIKARI' && sourceToken.symbol === 'ETH') {
      console.log('Source is ETH and Target Hikari');
      sellRate = ethUSDT.data.price;
      buyRate = hikariPrice.data['hikari-protocol'].usd;
    } else if (targetToken.symbol === 'ETH' && sourceToken.symbol === 'HIKARI') {
      console.log('Source is Hikari and Target ETH');
      buyRate = ethUSDT.data.price;
      sellRate = hikariPrice.data['hikari-protocol'].usd;
    }

    // if (sourceToken.name == "HIKARI") {
    //   let hikariPrice = await axios.get(
    //     "https://api.coingecko.com/api/v3/simple/price?ids=ethereum%2Chikari-protocol&vs_currencies=usd&include_market_cap=false&include_24hr_vol=false&include_24hr_change=false&include_last_updated_at=false"
    //   );
    //   sellRate = hikariPrice.data["hikari-protocol"].usd;
    //   console.log("Source 1");
    // } else if (sourceToken != "USDT") {
    //   const sellUSD = await axios.get(
    //     `https://www.binance.com/api/v3/ticker/price?symbol=${sourceToken.symbol}USDT`
    //   );
    //   sellRate = sellUSD.data.price;
    //   console.log("Source 2");
    // }

    // if (targetToken.name == "HIKARI") {
    //   let hikariPrice = await axios.get(
    //     "https://api.coingecko.com/api/v3/simple/price?ids=ethereum%2Chikari-protocol&vs_currencies=usd&include_market_cap=false&include_24hr_vol=false&include_24hr_change=false&include_last_updated_at=false"
    //   );
    //   buyRate = hikariPrice.data["hikari-protocol"].usd;
    //   console.log("Source 3");
    // } else if (targetToken != "USDT") {
    //   const sellUSD = await axios.get(
    //     `https://www.binance.com/api/v3/ticker/price?symbol=${targetToken.symbol}USDT`
    //   );
    //   buyRate = sellUSD.data.price;
    //   console.log("Source 4");
    // }

    console.log(sellRate, buyRate);

    if (buyAmt !== -1) {
      setSellAmount((buyAmt * buyRate) / sellRate);
      console.log('sellAmount', sellAmount);
    } else if (sellAmt !== -1) {
      setBuyAmount((sellAmt * sellRate) / buyRate);
      console.log('buyAmount', buyAmount);
    } else {
      setBuyAmount((sellAmount * sellRate) / buyRate);
      console.log('buyAmount 2', buyAmount);
    }
  };

  useEffect(() => {
    calcToken();
  }, [sourceToken, targetToken]);

  useEffect(() => {
    tokenList.length > 0 && getTokenList();
    console.log(window.ethereum.networkVersion);
    if (window.ethereum.networkVersion != 1)
      toaster('error', 'This platform works on only Mainnet');
    // eslint-disable-next-line
  }, [account]);

  useEffect(() => {
    tokenList.length === 0 && getTokenList();

    // eslint-disable-next-line
  }, [tokenList]);

  const getAllData = () => {
    FetchOrders();
    FetchTwap();
    FetchVwap();
  };

  useEffect(() => {
    getAllData();
    // eslint-disable-next-line
  }, [advanced]);

  useEffect(() => {
    if (otcOrder && advanced) {
      setDuration(null);
      setBuyAmount(null);
      setSellAmount(null);
      setBuyEveryX(null);

      setSellEveryX(0);
    }
  }, [otcOrder, advanced]);

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  return (
    <Box>
      <Container>
        {window.ethereum.networkVersion == 1 && (
          <Box display='flex' justifyContent='center' alignItems='center' width='100%'>
            <Stack
              sx={{
                width: { xs: '100%', md: '40em' },
                my: 15,
                background: '#fffcf1',
                opacity: 0.92,
                boxShadow: 'inset 0px 4px 4px rgba(0, 0, 0, 0.25)',
                borderRadius: 3,
                px: 2,
                py: 2,
              }}
            >
              <Box>
                <Container sx={{ display: 'flex', justifyContent: 'center', mt: 2, p: 0 }}>
                  {true && (
                    <Link
                      href='#'
                      onClick={() => {
                        console.log('Here');
                        setBuyAmount(null);
                        setSellAmount(null);
                        setBuyEveryX(null);

                        if (!pending) {
                          setAdvanced(!advanced);
                          if (advanced) {
                            setTwapCreated(!twapCreated);
                          }
                        }
                      }}
                      sx={{
                        color: 'black',
                        fontSize: '1em',
                        mx: 1,
                        letterSpacing: '0.18px',
                        textDecoration: 'underline',
                      }}
                    >
                      {!advanced ? (
                        <AdvancedText>Advanced Options</AdvancedText>
                      ) : (
                        <>
                          <img src='/images/back.png' style={{ width: '30px' }}></img>
                          <BackText>Back</BackText>
                        </>
                      )}
                    </Link>
                  )}
                </Container>
              </Box>

              <Container sx={{ mt: 2, mx: 0, p: 0 }}>
                <Stack direction='row' justifyContent='space-between' alignItems='center'>
                  <Typography sx={{ fontSize: '1em', mx: 1 }}>Trade</Typography>
                  <IconButton>
                    <SettingsIcon />
                  </IconButton>
                </Stack>
              </Container>

              {!advanced && (
                <>
                  {/* swap input */}
                  <PayAndReceiveInput
                    invert={invert}
                    onChangedInvert={() => {
                      if (invert) {
                        setSourceToken(myTokens[0]);
                        setTargetToken(myTokens[2]);
                      } else {
                        setSourceToken(myTokens[2]);
                        setTargetToken(myTokens[0]);
                      }
                      setInvert(!invert);
                    }}
                    account={account}
                    buyAmount={buyAmount}
                    sellAmount={sellAmount}
                    onChangedSellAmount={async (e) => {
                      setSellAmount(e.target.value);
                      calcToken(e.target.value, -1);
                    }}
                    onChangedBuyAmount={(e) => {
                      setBuyAmount(e.target.value);
                      calcToken(-1, e.target.value);
                    }}
                  />
                </>
              )}

              {!advanced && (
                <>
                  <Container
                    sx={{
                      display: { xs: 'block', md: 'flex' },
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: 3,
                      px: 1,
                      py: 1,
                    }}
                  >
                    <Box
                      sx={{
                        width: '100%',
                        mx: 0,
                        py: 1,
                        px: 2,
                        mt: -0.5,
                        // border: '1px solid #20242A',
                        borderRadius: 3,
                        background: '#f8eecd',
                      }}
                    >
                      <ExpiresInInput
                        expires={expired}
                        onChangedExpires={(e) => {
                          setExpired(e.target.value);
                        }}
                        duration={duration}
                        onChangeDuration={handleDuration}
                      />
                    </Box>
                  </Container>
                  <Box>
                    <Container sx={{ display: 'flex', justifyContent: 'end', mt: 2, p: 0 }}>
                      <Button
                        variant='contained'
                        sx={{
                          background: '#B2B9D2',
                          color: '#ffffff',
                          borderRadius: 3,
                          mx: 1,
                        }}
                        fullWidth={isMobile}
                        pending={(pending === false).toString()}
                        onClick={() => !pending && CreateOrder()}
                        disabled={pending}
                      >
                        {!pending ? (
                          <>
                            Create
                            <AiOutlineArrowRight />
                          </>
                        ) : (
                          <>
                            Create
                            <AiOutlineArrowRight />
                            <CircularProgress
                              size={24}
                              sx={{
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                                marginTop: '-12px',
                                marginLeft: '-12px',
                              }}
                            />
                          </>
                        )}
                      </Button>
                    </Container>
                  </Box>
                </>
              )}

              {advanced &&
                (listOrders.length > 0 ? (
                  <>
                    <Stack>
                      <Tabs
                        defaultValue={0}
                        onChange={(_, newValue) => {
                          handleChangeTWAP(newValue === 0);
                        }}
                      >
                        <StyledTabsList>
                          <StyledTab value={0}>TWAP</StyledTab>
                          <StyledTab value={1}>VWAP</StyledTab>
                        </StyledTabsList>
                        <StyledTabPanel value={0}>
                          <TwapInputs
                            otcOrder={otcOrder}
                            onChangeOtcOrder={(e) => {
                              const seletedOrder =
                                listOrders[
                                  listOrders.findIndex((item) => item.orderId === e.target.value)
                                ];
                              setOtcOrder(seletedOrder);
                            }}
                            listOrders={listOrders}
                            duration={duration}
                            onChangeDuration={handleDuration}
                            buyAmount={buyAmount}
                            onChangeBuyAmount={(e) => {
                              setBuyAmount(e.target.value);
                            }}
                            buyEveryX={buyEveryX}
                            onChangeBuyEveryX={(e) => {
                              setBuyEveryX(e.target.value);
                            }}
                            sellAmount={sellAmount}
                            onChnangeSellAmount={(e) => {
                              setSellAmount(e.target.value);
                            }}
                            sellEveryX={sellEveryX}
                            onChangeSellEveryX={(e) => {
                              setSellEveryX(e.target.value);
                            }}
                            pending={pending}
                            handleCreateTwap={() => {
                              if (!pending) {
                                setSourceToken({
                                  address: otcOrder.sellTokenAddress,
                                  symbol: otcOrder.sellTokenSymbol,
                                });
                                setTargetToken({
                                  address: otcOrder.buyTokenAddress,
                                  symbol: otcOrder.buyTokenSymbol,
                                });

                                Twap(
                                  {
                                    address: otcOrder.sellTokenAddress,
                                    symbol: otcOrder.sellTokenSymbol,
                                  },
                                  {
                                    address: otcOrder.buyTokenAddress,
                                    symbol: otcOrder.buyTokenSymbol,
                                  },
                                );
                              }
                            }}
                          />
                        </StyledTabPanel>
                        <StyledTabPanel value={1}>
                          <VwapInputs
                            otcOrder={otcOrder}
                            listOrders={listOrders}
                            onChangeOtcOrder={(e) => {
                              const seletedOrder =
                                listOrders[
                                  listOrders.findIndex((item) => item.orderId === e.target.value)
                                ];
                              setOtcOrder(seletedOrder);
                            }}
                            duration={duration}
                            onChangeDuration={handleDuration}
                            buyAmount={buyAmount}
                            onChangeBuyAmount={(e) => {
                              setBuyAmount(e.target.value);
                            }}
                            pending={pending}
                            handleCreateVwap={() => {
                              if (!pending) {
                                setSourceToken({
                                  address: otcOrder.sellTokenAddress,
                                  symbol: otcOrder.sellTokenSymbol,
                                });
                                setTargetToken({
                                  address: otcOrder.buyTokenAddress,
                                  symbol: otcOrder.buyTokenSymbol,
                                });

                                Vwap(
                                  {
                                    address: otcOrder.sellTokenAddress,
                                    symbol: otcOrder.sellTokenSymbol,
                                  },
                                  {
                                    address: otcOrder.buyTokenAddress,
                                    symbol: otcOrder.buyTokenSymbol,
                                  },
                                );
                              }
                            }}
                          />
                        </StyledTabPanel>
                      </Tabs>
                    </Stack>
                  </>
                ) : (
                  <>
                    <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                      You do not have an active OTC trade in the pool.
                    </Box>
                  </>
                ))}

              {advanced && twapList.length > 0 && (
                <>
                  <Stack my={1} mb={5}>
                    <TradeText sx={{ textAlign: 'center' }}>Your current running twap</TradeText>
                    {twapList.map((twapItem, index) => (
                      <Stack key={index}>
                        <Stack
                          direction='row'
                          justifyContent={'space-between'}
                          alignItems={'center'}
                        >
                          <PriceUtils OTCItem={twapItem} uniswapV2Router={uniswapV2Router} />
                          <Stack>
                            <Button
                              variant='contained'
                              sx={{
                                background: '#FF0000',
                                color: '#ffffff',
                                borderRadius: 3,
                                mx: 1,
                              }}
                              onClick={() => cancelTwap(twapItem)}
                            >
                              Cancel
                            </Button>
                          </Stack>
                        </Stack>
                        <Divider />
                      </Stack>
                    ))}
                  </Stack>
                </>
              )}

              {advanced && vwapList.length > 0 && (
                <Stack mb={5}>
                  <TradeText sx={{ textAlign: 'center' }}>Your current running vwap</TradeText>
                  {vwapList.map((vwapItem, index) => (
                    <Stack key={index}>
                      <Stack direction='row' justifyContent={'space-between'} alignItems={'center'}>
                        <Stack>{`buying ${vwapItem.buyAmount} ${vwapItem.sourceToken.symbol} worth of ${vwapItem.sellAmount} ${vwapItem.targetToken.symbol} every ${vwapItem.buyEveryX} minutes`}</Stack>
                        <Stack>
                          <Button onClick={() => cancelVwap(vwapItem)}>Cancel VWAP</Button>
                        </Stack>
                      </Stack>
                      <Divider />
                    </Stack>
                  ))}
                </Stack>
              )}
            </Stack>
          </Box>
        )}
      </Container>
    </Box>
  );
}

export const CreateBtn = styled(Box)`
  opacity: 0.75;
  border: 1px solid #30252f;
  border-radius: 28px;
  padding: 12px 28px;
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-size: 15px;
  line-height: 18px;

  color: #000000;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  cursor: ${({ pending }) => (pending === 'true' ? 'pointer' : 'not-allowed')};
  position: relative;
  :hover {
    background-color: rgb(75, 198, 139);
    color: white;
  }
  transition: all 0.5s ease-out;
`;

const champagne = {
  50: '#fffffc',
  100: '#fffefa',
  200: '#fcfbf2',
  300: '#fcfaeb',
  400: '#faf4dc',
  500: '#f8eecd',
  600: '#decfa6',
  700: '#baa373',
  800: '#94784a',
  900: '#70502a',
  950: '#472c11',
};

const grey = {
  50: '#f6f8fa',
  100: '#eaeef2',
  200: '#d0d7de',
  300: '#afb8c1',
  400: '#8c959f',
  500: '#6e7781',
  600: '#57606a',
  700: '#424a53',
  800: '#32383f',
  900: '#24292f',
};

const StyledTab = styled(Tab)`
  font-family: 'IBM Plex Sans', sans-serif;
  color: #000000;
  cursor: pointer;
  font-size: 0.875rem;
  font-weight: 600;
  background-color: transparent;
  width: 100%;
  padding: 10px 12px;
  margin: 6px;
  border: none;
  border-radius: 7px;
  display: flex;
  justify-content: center;

  &:hover {
    background-color: ${champagne[400]};
  }

  &:focus {
    color: #fff;
    outline: 3px solid ${champagne[200]};
  }

  &.${tabClasses.selected} {
    background-color: #fff;
    color: ${champagne[900]};
  }

  &.${buttonClasses.disabled} {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;

const StyledTabPanel = styled(TabPanel)(
  ({ theme }) => `
  width: 100%;
  font-family: IBM Plex Sans, sans-serif;
  font-size: 0.875rem;
  padding: 0;
  margin: 
  border: 1px solid ${theme.palette.mode === 'dark' ? champagne[700] : champagne[200]};
  border-radius: 12px;
  `,
);

const StyledTabsList = styled(TabsList)(
  ({ theme }) => `
  min-width: 100%;
  background-color: ${champagne[500]};
  border-radius: 12px;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  align-content: space-between;
  box-shadow: 0px 4px 30px ${theme.palette.mode === 'dark' ? grey[900] : grey[200]};
  `,
);

export default Trade;
