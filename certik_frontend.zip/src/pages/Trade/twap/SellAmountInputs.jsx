import {
  Box,
  FormControl,
  Stack,
  TextField,
  Typography,
  useMediaQuery,
  useTheme,
} from '@mui/material';

const SellAmountInputs = ({
  hint,
  sellHint,
  sellAmount,
  onChangedSellAmount,
  sellEveryX,
  onChangedSellEveryX,
}) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  return (
    <Stack>
      <Box sx={{ display: isMobile ? 'block' : 'flex' }}>
        {/* sell amount */}
        <Box
          sx={{
            width: '100%',
            mx: 0,
            mt: 1,
            py: 1,
            px: 2,
            // border: '1px solid #20242A',
            borderRadius: 3,
            background: '#f8eecd',
          }}
        >
          <Stack>
            {/* header */}
            <Stack>
              <Typography sx={{ fontSize: 12, color: 'gray' }}>Sell amount</Typography>
            </Stack>

            {/* input and quick time buttons*/}
            <Stack direction='row' display='flex' justifyContent='space-between'>
              <FormControl variant='standard'>
                <TextField
                  inputProps={{
                    inputMode: 'numeric',
                    pattern: '[0-9]*',
                    placeholder: `${hint ? hint : ''}`,
                  }}
                  sx={{
                    width: { xs: '70vw', md: '12em' },
                    fontSize: 20,
                    '& fieldset': { border: 'none' },
                  }}
                  value={sellAmount}
                  onChange={onChangedSellAmount}
                />
              </FormControl>
            </Stack>
          </Stack>
        </Box>
        {/* sell every */}
        <Box
          sx={{
            width: '100%',
            mx: 0,
            mt: 1,
            py: 1,
            px: 2,
            ml: { xs: 0, md: 1 },
            // border: '1px solid #20242A',
            borderRadius: 3,
            background: '#f8eecd',
          }}
        >
          <Stack>
            {/* header */}
            <Stack>
              <Typography sx={{ fontSize: 12, color: 'gray' }}>
                Sell every X{sellHint ? sellHint : ''}
              </Typography>
            </Stack>

            {/* input and quick time buttons*/}
            <Stack direction='row' display='flex' justifyContent='space-between'>
              <FormControl variant='standard'>
                <TextField
                  inputProps={{
                    inputMode: 'numeric',
                    pattern: '[0-9]*',
                  }}
                  sx={{
                    width: { xs: '70vw', md: '12em' },
                    fontSize: 20,
                    '& fieldset': { border: 'none' },
                  }}
                  value={sellEveryX}
                  onChange={onChangedSellEveryX}
                />
              </FormControl>
            </Stack>
          </Stack>
        </Box>
      </Box>
    </Stack>
  );
};

export default SellAmountInputs;
