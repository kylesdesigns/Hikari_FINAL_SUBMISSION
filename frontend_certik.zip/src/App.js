import { BrowserRouter } from 'react-router-dom';
import Routes from './routes';
import TopBar from './components/Topbar';
import Parse from 'parse/dist/parse.min.js';
import theme from './utils/theme';
import { CssBaseline, ThemeProvider } from '@mui/material';

import { createWeb3Modal, defaultWagmiConfig } from '@web3modal/wagmi/react';

import { WagmiConfig } from 'wagmi';
import { mainnet } from 'wagmi/chains';

// Your Parse initialization configuration goes here
const PARSE_APPLICATION_ID = '';
const PARSE_HOST_URL = '';
const PARSE_JAVASCRIPT_KEY = '';
Parse.initialize(PARSE_APPLICATION_ID, PARSE_JAVASCRIPT_KEY);
Parse.serverURL = PARSE_HOST_URL;

// 1. Get projectId
const projectId = '';

// 2. Create wagmiConfig
const metadata = {
  name: 'Web3Modal',
  description: 'Web3Modal Example',
  url: 'https://web3modal.com',
  icons: ['https://avatars.githubusercontent.com/u/37784886'],
};

const chains = [mainnet];
const wagmiConfig = defaultWagmiConfig({ chains, projectId, metadata });

// 3. Create modal
createWeb3Modal({ wagmiConfig, projectId, chains });

function App() {
  return (
    <WagmiConfig config={wagmiConfig}>
      <ThemeProvider theme={theme}>
        <BrowserRouter>
          <CssBaseline />
          <TopBar />
          <Routes />
        </BrowserRouter>
      </ThemeProvider>
    </WagmiConfig>
  );
}

export default App;
