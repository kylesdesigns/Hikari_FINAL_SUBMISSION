/* eslint-disable jsx-a11y/alt-text */
import { Box } from '@mui/material';
import { Title, Main, Content } from '../../styles/featuresStyles';

function Features() {
  return (
    <Box position={'relative'} width='100%'>
      <Title>Introducing the future of OTC token swaps on Ethereum.</Title>
      <Content>
        <Main>
          We've integrated <b>dark market</b> pools with <b>lit markets</b> which allows <br /> you
          to achieve unique order types that were only on <b>sophisticated markets.</b>
        </Main>
        <ui style={{ textAlign: 'center' }}>
          <li style={{ marginTop: '20px' }}>
            Access low slippage and private trades for your larger block trades.
          </li>
          <li style={{ marginTop: '20px' }}>
            Trade using various order types to break down your trades easier.
          </li>
          <li style={{ marginTop: '20px' }}>
            Execute more trades with our combination of OTC pools and open swap protocols.
          </li>
          <li style={{ marginTop: '20px' }}>
            Swap privately with trusted counterparties using our secure OTC feature.
          </li>
        </ui>
      </Content>
    </Box>
  );
}

export default Features;
