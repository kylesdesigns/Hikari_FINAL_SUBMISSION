/* eslint-disable jsx-a11y/alt-text */
import React, { useState, useEffect } from 'react';
import {
  Box,
  CircularProgress,
  TextField,
  Stack,
  Button,
  Grid,
  FormControlLabel,
  Switch,
  Table,
  TableCell,
  TableHead,
  TableBody,
  TableRow,
  Paper,
  Modal,
  Typography,
  Backdrop,
  Fade,
} from '@mui/material';
import { db } from '../../utils/firebase';
import { TradeBox, TradeHead } from '../../styles/ordersStyles';
// import axios from "axios";
// import { ConstructionOutlined } from "@mui/icons-material";
import { useWeb3Context, useAddress } from '../../hooks/web3Context';
import { getTokenContract } from '../../utils/contracts';
import { ethers } from 'ethers';
import { toaster } from '../../utils/toast';
import axios from 'axios';
import styled from 'styled-components';
// import { myTokens } from "../../utils/tokens";
import { backendUrl } from '../../config';
function Orders() {
  const account = useAddress();
  const { provider } = useWeb3Context();
  const [listOrders, setListOrders] = useState([]);
  const [pending, setPending] = useState(false);
  const [filterString, setFilterString] = useState('');
  const [showOrders, setShowOrders] = useState([]);
  const [filterCompleteSearch, setFilterCompleteSearch] = useState(false);
  const [open, setOpen] = useState(false);
  const [closeItem, setCloseItem] = useState({});
  const [fetchingGasPrice, setFetchingGasPrice] = useState(false);
  const [ethCurrentTxGasEstimate, setEthCurrentTxGasEstimate] = useState(0.0);
  const [closingOrder, setClosingOrder] = useState(false);
  const FetchOrders = async () => {
    const res = await db.collection('orders').get();
    const orders = res.docs.map((doc) => doc.data());
    setListOrders(
      orders.sort((a, b) => {
        return b.orderId - a.orderId;
      }),
    );
    setShowOrders(
      orders.sort((a, b) => {
        return b.orderId - a.orderId;
      }),
    );
  };

  useEffect(() => {
    FetchOrders();
  }, []);

  const handleFulFilOrder = async (item) => {
    if (!account) {
      toaster('error', 'Please connect your wallet');
      return;
    }
    if (item.targetUser !== '' && item.targetUser !== account) {
      toaster('error', "You don't have permission to fulfil this order");
      return;
    }

    setPending(true);
    try {
      if (item.buyTokenSymbol === 'ETH') {
        const balance = await provider.getBalance(account);
        if (Number(ethers.utils.formatUnits(balance, 18)) < item.buyTokenAmount) {
          toaster('error', `you don't have enough ${item.buyTokenSymbol}`);
          setPending(false);
          return;
        }

        const tx = {
          from: account,
          to: item._owner,
          value: ethers.utils.parseEther(`${item.buyTokenAmount.toFixed(18)}`),
          nonce: provider.getTransactionCount(account, 'latest'),
        };

        await provider.getSigner().sendTransaction(tx);
      } else {
        console.log('Enter');
        const tokenContract1 = getTokenContract(item.buyTokenAddress, provider.getSigner());

        const balance = await tokenContract1.balanceOf(account);

        if (Number(ethers.utils.formatUnits(balance, 18)) < item.buyTokenAmount) {
          toaster('error', `you don't have enough token`);
          setPending(false);
          return;
        }

        console.log('item.buyTokenAmount', item.buyTokenAmount);

        const tx = await tokenContract1.transfer(
          item._owner,
          ethers.utils.parseEther(`${item.buyTokenAmount}`),
        );
        await tx.wait();
      }

      const result = await db.collection('orders').get();
      var dbData = result.docs.map((doc) => doc.data());
      var orderIDs = result.docs.map((doc) => doc.id);
      let dIndex = dbData.findIndex((i) => i.orderId === item.orderId);
      await db.collection('orders').doc(orderIDs[dIndex]).update({
        receiver: account,
      });

      axios
        .post(
          `${backendUrl}full_fillorder`,
          {
            ...item,
            receiver: account,
          },
          {
            'Content-Type': 'application/json',
          },
        )
        .then((response) => {
          setPending(false);
          if (response.data.status) {
            toaster('success', 'OTC Done');
            FetchOrders();
          } else {
            toaster('error', 'Server Error');
          }
        });
    } catch (error) {
      toaster('error', 'Something went wrong');
      console.error(error);
      setPending(false);
    }
  };

  const handleCloseOrder = async (item) => {
    console.log(item);
    setPending(true);
    setClosingOrder(true);
    const jwt = localStorage.getItem('jwt');

    axios
      .post(`${backendUrl}close_order`, item, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${jwt}`,
        },
      })
      .then((response) => {
        setPending(false);
        if (response.data.status) {
          setOpen(false);
          setClosingOrder(false);
          toaster('success', 'Order Closed');
          FetchOrders();
        } else {
          console.log(response);
          toaster('error', 'Server Error');
          setOpen(false);
          setClosingOrder(false);
          FetchOrders();
        }
      })
      .catch((e) => {
        setPending(false);
        setClosingOrder(false);
        setOpen(false);
        toaster('error', 'Order could not be closed, please try again later');
      });
  };

  const filterTransaction = async () => {
    const newArray = listOrders.filter((el) => {
      if (el.sellTokenSymbol.toLowerCase().includes(filterString.toLowerCase())) return true;
      else return el.buyTokenSymbol.toLowerCase().includes(filterString.toLowerCase());
    });
    setShowOrders(newArray);
  };

  const filterFinishTransaction = () => {
    setFilterCompleteSearch(!filterCompleteSearch);
    let newArray;
    if (!filterCompleteSearch) {
      newArray = listOrders.filter((el) => {
        return el.otc === 2;
      });
      setShowOrders(newArray);
    } else setShowOrders(listOrders);
  };

  const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: '#fff3d7',
    border: '2px solid #fff3d7',
    borderRadius: 5,
    boxShadow: 24,
    p: 4,
  };

  const handleOpenEstimatePayoutModel = async (item) => {
    console.log(item);
    setFetchingGasPrice(true);
    if (item == null) {
      toaster('error', 'Server Error #3320, contact support');
      return;
    } else if (item._owner === null) {
      toaster('error', 'Server Error #3321, contact support');
      return;
    }
    setOpen(true);

    if (item.sellTokenSymbol === 'ETH') {
      try {
        axios
          .post(`${backendUrl}estimate_close_order`, item, {
            'Content-Type': 'application/json',
          })
          .then((response) => {
            setPending(false);
            if (response.data.gas) {
              setFetchingGasPrice(false);
              console.log('gas calculated:', response.data.gas);
              setEthCurrentTxGasEstimate(response.data.gas);
              // toaster("success", "Order Closed");
              // FetchOrders();
            } else {
              toaster('error', 'Server Error #3323, contract support');
            }
          })
          .catch((e) => {
            setFetchingGasPrice(false);
            toaster('error', 'Failed to estimate gas');
          });
      } catch (e) {
        console.error(e);
        toaster('error', 'Server Error #3322, contact support');
      }
      setOpen(true);
    } else {
      handleCloseOrder(item);
    }
  };

  const handleCloseEstimatePayoutModel = () => {
    setOpen(false);
  };

  return (
    <Box position={'relative'} sx={{ width: '100%' }}>
      <TradeBox sx={{ width: '100%' }}>
        <TradeHead>Order List</TradeHead>
        <Grid container spacing={2} display='flex' justifyContent='center'>
          <Grid item md={4}>
            <Stack direction='row'>
              <Box>
                <TextField
                  value={filterString.toUpperCase()}
                  onChange={(e) => {
                    setFilterString(e.target.value);
                  }}
                  sx={{ color: 'black', textTransform: 'uppercase' }}
                  placeholder='Search by Token'
                  variant='outlined'
                />
              </Box>
              <Button
                variant='outlined'
                color='success'
                sx={{ marginLeft: '10px' }}
                onClick={filterTransaction}
              >
                Filter
              </Button>
            </Stack>
          </Grid>
          <Grid item md={5}></Grid>
          <Grid item md={3} display='flex' justifyContent='center'>
            <FormControlLabel
              control={
                <Switch
                  checked={filterCompleteSearch}
                  onChange={() => {
                    filterFinishTransaction();
                  }}
                />
              }
              label='Show Only Finished Transaction'
            />
          </Grid>
        </Grid>
        <Paper
          sx={{
            overflowX: 'auto',
            marginRight: 'auto',
            marginLeft: 'auto',
            background: 'transparent',
          }}
        >
          <Table id='orders'>
            <TableHead>
              <TableRow>
                <TableCell>OrderId</TableCell>
                <TableCell>Sell Token</TableCell>
                <TableCell>SellToken Address</TableCell>
                <TableCell>SellToken Amount</TableCell>
                <TableCell>Buy Token</TableCell>
                <TableCell>BuyToken Address</TableCell>
                <TableCell>BuyToken Amount</TableCell>
                <TableCell>OTC</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {showOrders !== null &&
                showOrders !== undefined &&
                showOrders.length > 0 &&
                showOrders.map((item, index) => {
                  return (
                    <TableRow key={index}>
                      <TableCell>{item.orderId}</TableCell>
                      <TableCell>${item.sellTokenSymbol}</TableCell>
                      <TableCell>{item.sellTokenAddress}</TableCell>
                      <TableCell>{item.sellTokenAmount}</TableCell>
                      <TableCell>${item.buyTokenSymbol}</TableCell>
                      <TableCell>{item.buyTokenAddress}</TableCell>
                      <TableCell>{item.buyTokenAmount}</TableCell>
                      <TableCell>
                        {item.otc !== 2 &&
                          item.otc !== 3 &&
                          item.otc !== 4 &&
                          item.otc !== 5 &&
                          item._owner === account && (
                            <FulfilBtn
                              pending={(pending === false).toString()}
                              onClick={() => {
                                // TODO first popup estimated payout
                                // if (!pending) handleCloseOrder(item);
                                if (!pending) setCloseItem(item);

                                if (!pending) handleOpenEstimatePayoutModel(item);
                              }}
                            >
                              Close order
                            </FulfilBtn>
                          )}
                        {item._owner !== account && item.otc === 1 && (
                          <FulfilBtn
                            pending={(pending === false).toString()}
                            onClick={() => {
                              if (!pending) handleFulFilOrder(item);
                            }}
                          >
                            {!pending ? (
                              <>Fulfil Order</>
                            ) : (
                              <>
                                Fulfil Order
                                <CircularProgress
                                  size={24}
                                  sx={{
                                    position: 'absolute',
                                    top: '50%',
                                    left: '50%',
                                    marginTop: '-12px',
                                    marginLeft: '-12px',
                                  }}
                                />
                              </>
                            )}
                          </FulfilBtn>
                        )}
                        {item.otc === 2 && 'Finished'}
                        {item.otc === 3 && 'Expired'}
                        {item.otc === 4 && 'Twaping'}
                        {item.otc === 5 && 'Vwaping'}
                      </TableCell>
                    </TableRow>
                  );
                })}
            </TableBody>
          </Table>
        </Paper>
      </TradeBox>
      <Modal
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        open={open}
        onClose={handleCloseEstimatePayoutModel}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}
      >
        <Fade in={open}>
          <Box sx={style}>
            <Typography id='transition-modal-title' variant='h6' component='h2'>
              {fetchingGasPrice ? 'Estimating payout...' : `Estimated payout`}
            </Typography>
            {!fetchingGasPrice && (
              <Typography id='transition-modal-description' sx={{ mt: 2 }}>
                <Typography>{`Amount: ${closeItem.sellTokenAmount} ETH`}</Typography>
                <Typography>{`Gas: ${ethCurrentTxGasEstimate / 1000000000} ETH`}</Typography>
              </Typography>
            )}
            {!fetchingGasPrice && (
              <Typography>
                {`estimated total: ${
                  closeItem.sellTokenAmount - ethCurrentTxGasEstimate / 1000000000
                } ETH`}
              </Typography>
            )}

            {!fetchingGasPrice && (
              <Stack direction='row' spacing={2} mt={2}>
                <Button
                  color='success'
                  variant='contained'
                  disabled={closeItem.sellTokenAmount - ethCurrentTxGasEstimate / 1000000000 <= 0}
                  onClick={() => (!closingOrder ? handleCloseOrder(closeItem) : {})}
                >
                  {!closingOrder ? 'Close Order' : 'Closing...'}
                </Button>
                <Button
                  variant='contained'
                  href='#contained-buttons'
                  onClick={handleCloseEstimatePayoutModel}
                >
                  Close
                </Button>
              </Stack>
            )}
          </Box>
        </Fade>
      </Modal>
    </Box>
  );
}

export default Orders;

export const FulfilBtn = styled(Box)`
  opacity: 0.75;
  border: 1px solid #30252f;
  border-radius: 28px;
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-size: 15px;
  line-height: 18px;

  color: #000000;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  cursor: ${({ pending }) => (pending === 'true' ? 'pointer' : 'not-allowed')};
  position: relative;
  :hover {
    background-color: rgb(75, 198, 139);
    color: white;
  }
  transition: all 0.5s ease-out;
`;
