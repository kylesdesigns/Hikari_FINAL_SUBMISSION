import { Outlet } from 'react-router-dom';
import { Box } from '@mui/material';
import { Background, StyledContainer } from '../styles/faqStyles';

const FAQLayout = ({ children }) => {
  return (
    <StyledContainer>
      <Background />

      <Box sx={{ display: 'flex' }}>{!children && <Outlet />}</Box>
    </StyledContainer>
  );
};

export default FAQLayout;
