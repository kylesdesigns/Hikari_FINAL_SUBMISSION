import { Outlet } from 'react-router-dom';
import { Box } from '@mui/material';
import { Background } from '../styles';

const MainLayout = ({ children }) => {
  return (
    <div>
      <Background />

      <Box sx={{ display: 'flex' }}>{!children && <Outlet />}</Box>
    </div>
  );
};

export default MainLayout;
