import { useRoutes } from 'react-router-dom';

import MainRoutes from './MainRoutes';
import FeaturesRoutes from './FeaturesRoutes';
import PartnerShipRoutes from './PartnerShipRoutes';
import TradeRoutes from './TradeRoutes';
import OrdersRoutes from './OrdersRoutes';
import FAQRoutes from './FAQRoutes';

import Error from '../pages/Error';

export default function ThemeRoutes() {
  return useRoutes([
    MainRoutes,
    FeaturesRoutes,
    PartnerShipRoutes,
    TradeRoutes,
    OrdersRoutes,
    FAQRoutes,
    { path: '*', element: <Error /> },
  ]);
}
