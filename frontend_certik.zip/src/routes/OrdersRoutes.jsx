import OrdersLayout from '../layout/OrdersLayout';

import Orders from '../pages/Orders';

const OrdersRoutes = {
  path: '/',
  element: <OrdersLayout />,
  children: [
    {
      path: '/orders',
      element: <Orders />,
    },
  ],
};

export default OrdersRoutes;
