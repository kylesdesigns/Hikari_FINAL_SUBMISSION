import { Stack } from '@mui/material';
import { ReactNode } from 'react';

const NavbarLinkButton = ({ children, ...props }) => {
  return (
    <Stack
      direction='row'
      alignItems='center'
      spacing={1}
      sx={{ cursor: 'pointer', color: 'text.secondary', '&.hover': { color: 'text.primary' } }}
      {...props}
    >
      {children}
    </Stack>
  );
};

export default NavbarLinkButton;
