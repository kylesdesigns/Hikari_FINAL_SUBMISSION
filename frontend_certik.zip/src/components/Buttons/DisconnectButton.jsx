import { Button } from '@mui/material';
import PropTypes from 'prop-types';
import { useEffect } from 'react';
import { useAddress, useWeb3Context } from '../../hooks/web3Context';

const DisconnectButton = ({ sx = {}, ...props }) => {
  const account = useAddress();
  const { connect, disconnect } = useWeb3Context();

  const connectWallet = () => {
    connect().then((msg) => {
      console.log(msg);
    });
  };

  const disconnectWallet = () => {
    disconnect().then((msg) => {
      console.log(msg);
    });
  };

  useEffect(() => {
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', (accounts) => {
        // addAccount({ id: accounts[0] })
        connectWallet();
      });
      window.ethereum.on('chainChanged', (chainId) => {
        window.location.reload();
      });
    }
    // eslint-disable-next-line
  }, [account]);

  return (
    <Button
      variant='outlined'
      sx={{ borderRadius: 3, ...sx }}
      {...props}
      onClick={() => disconnectWallet}
    >
      {`${account?.substring(0, 5)}...${account?.substring(account?.length - 5, account?.length)}`}
    </Button>
  );
};

DisconnectButton.propTypes = {
  sx: PropTypes.object,
};

export default DisconnectButton;
