import { createTheme } from '@mui/material';
import themeTypography from './typography';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#f8eecd',
    },
    background: {
      default: '#f8eecd',
    },
    text: {
      secondary: '#4B4A54',
    },
  },
  typography: {
    ...themeTypography,
  },
});

export default theme;
