export const navbarHeight = 80;
