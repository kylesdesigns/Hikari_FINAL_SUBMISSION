import { Button } from '@mui/material';
import PropTypes from 'prop-types';

const ConnectButton = ({ sx = {}, ...props }) => {
  return (
    <Button variant='outlined' sx={{ borderRadius: 3, ...sx }} {...props}>
      Connect
    </Button>
  );
};

ConnectButton.propTypes = {
  sx: PropTypes.object,
};

export default ConnectButton;
