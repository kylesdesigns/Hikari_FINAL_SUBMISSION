import {
  Box,
  Container,
  IconButton,
  List,
  ListItemButton,
  ListItemText,
  Stack,
  SwipeableDrawer,
} from '@mui/material';
import { navbarCenterLinks, navbarRightLinks } from '../../utils/content';
import CloseIcon from '@mui/icons-material/Close';
import { navbarHeight } from '../../constants';
import ConnectButton from '../Buttons/ConnectButton';
import DisconnectButton from '../Buttons/DisconnectButton';
import { useAddress, useWeb3Context } from '../../hooks/web3Context';

const Sidebar = ({ isSidebarOpen, onOpen, onClose }) => {
  const account = useAddress();
  const { connect, disconnect } = useWeb3Context();

  const connectWallet = () => {
    connect().then((msg) => {
      console.log(msg);
    });
  };

  const disconnectWallet = () => {
    disconnect().then((msg) => {
      console.log(msg);
    });
  };

  return (
    <SwipeableDrawer open={isSidebarOpen} onOpen={onOpen} onClose={onClose} anchor='right'>
      <Box
        sx={{
          backgroundColor: 'primary.main',
          minWidth: '250px',
          maxWidth: '250px',
          height: '100%',
        }}
      >
        <Stack
          direction='row'
          justifyContent='space-between'
          sx={{ height: navbarHeight }}
          alignItems='center'
        >
          <div />
          <IconButton sx={{ mr: 1 }} onClick={onClose}>
            <CloseIcon />
          </IconButton>
        </Stack>
        <List>
          {navbarCenterLinks.map((link) => {
            return (
              <ListItemButton href={link.linkTo} target={link.target} key={link.title}>
                <ListItemText primary={link.title} />
              </ListItemButton>
            );
          })}
          {navbarRightLinks.map((link) => {
            return (
              <ListItemButton href={link.linkTo} target={link.target} key={link.title}>
                <ListItemText primary={link.title} />
              </ListItemButton>
            );
          })}

          {/* Launch dApp */}

          <Container
            sx={{
              mt: 1,
            }}
          >
            {!account ? (
              <ConnectButton
                sx={{
                  height: 58,
                  width: '100%',
                  color: 'text.primary',
                  borderColor: 'text.primary',
                  px: 2,
                }}
                onClick={() => {
                  disconnectWallet();
                  connectWallet();
                }}
              />
            ) : (
              <DisconnectButton
                sx={{
                  height: 58,
                  width: '100%',
                  color: 'text.primary',
                  borderColor: 'text.primary',
                  px: 2,
                }}
              />
            )}
          </Container>
        </List>
      </Box>
    </SwipeableDrawer>
  );
};

export default Sidebar;
