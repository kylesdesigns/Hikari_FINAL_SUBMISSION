export interface IOTC {
  buyAmount?: string;
  tokenInAddress?: string;
  tokenOutAddress?: string;
  tokenInDecimals?: number;
  tokenOutDecimals?: number;
  amountOut?: string;
}

export interface IUseTransactionResponse {
  hash: string;
}

export interface IOrder {
  buyTokenAddress: string;
  buyTokenAmount: number;
  buyTokenSymbol: string;
  createdAt: number;
  duration: number;
  endTime: boolean;
  orderId: number;
  otc: number;
  sellTokenAddress: string;
  sellTokenAmount: number;
  sellTokenSymbol: string;
  targetUser: string;
  tx: string;
  tx2: string;
  _owner: string;
}

export interface IToken {
  name: string;
  address: string;
  logoURI: string;
  symbol: string;
}

export interface ITwap {
  _owner?: string;
  sourceToken?: IToken;
  sourceTokenBalance?: number;
  buyAmount?: number;
  buyEveryX?: number;
  buyNum?: number;
  network?: number;
  orderId?: number;
  targetToken?: IToken;
  targetTokenBalance?: number;
  sellAmount?: number;
  sellEveryX?: number;
  sellNum?: number;
  during?: number;
  duration?: number;
  startedTime?: number;
  endTime?: boolean;
  otcAmount?: number;
  otcAmountTotalUsed?: number;
}


export interface IExpiration {
  title: string;
  value: string;
}