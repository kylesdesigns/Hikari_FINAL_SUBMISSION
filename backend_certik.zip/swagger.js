const swaggerJsDoc = require('swagger-jsdoc');
const swaggerUI = require("swagger-ui-express")
var pjson = require('./package.json');

const options = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: "Hikari API",
            version: pjson.version,
            description: pjson.description,
        },
        basePath: '/',
        components: {
            securitySchemas: {
                bearerAuth: {
                    type: 'http',
                    scheme: 'bearer',
                    bearerFormat: 'JWT'
                }
            }
        },
        security: [
            {
                bearerAuth: [],
            }
        ]
    },
    apis: ['./index.js']
};

const swaggerSpec = swaggerJsDoc(options);

function swaggerDocs(app, port){
//  swagger page
app.use("/docs", swaggerUI.serve, swaggerUI.setup(swaggerSpec));
// Docs in json format
app.get('docs.json', (req, res)=> {
    res.setHeader("Content-Type", "application/json");
    res.send(swaggerSpec);
})

console.log(`Docs available at http://localhost:${port}/docs`)
}

module.exports = swaggerDocs;

